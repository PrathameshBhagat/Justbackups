<?php
echo "<script>function  j(){//while(true){
fetch('https://prathameshbhagat.000webhostapp.com/m/m.php')
    .then(response => {
        return response.text();
    })
    .then(data => document.getElementById('i').innerHTML=(data));}//}
    j();setInterval(function(){ j();}, 100);
</script><H1 id=i></h1>";
?>