<?php 
$conn = mysqli_connect('localhost','id19475742_root','Password@123','id19475742_project');
?>