<?php
if(isset($_GET['to']))$to=$_GET['to'];else

$subject = $_GET['sub'] ;
$txt =$_GET['txt'];
$headers = "From : \n <br>prathameshbhagat.000webhostapp.com/Doctor";
try{
echo mail("prathameshbhagat0608@gmail.com","$subject","$txt","$headers");}
 catch (Exception $e) {
    echo 'Caught exception: ',  $e->getMessage(), "\n";}
?>