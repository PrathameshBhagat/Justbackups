<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Document</title>
    <style>
        h3.question {
  font-family: "Roboto", sans-serif;
  font-size: 24px;
  text-align: center;
  font-weight: 100;
}

.editor-container {
  width: 900px;
  height: 540px;
  margin: 20px auto;
  position: relative;
}

#editor {
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  height: 100%;
  width: 100%;
  font-size: 20px;
}

    </style>
  </head>
  <body>

    <div class="editor-container">
      <div id="editor">// Program 
public class Main
{public static void main (String [] args{
System.out.print("आजी की  ऐसी की तैसे  is a rough word in hind please do not use such language in our messaging platform");
}</div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.5.3/ace.js"></script>

    <script language="javascript">let editor = document.querySelector("#editor");

ace.edit(editor, {
  theme: "ace/theme/cobalt",
  mode: "ace/mode/java",
});
</script>
  </body>
</html>
