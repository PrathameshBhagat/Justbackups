<?php 
$conn = mysqli_connect('localhost','id19475742_root','Password@123','id19475742_drones');

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>