<!DOCTYPE html>
<html>
<head>
  <title>Prathamesh Bhagat</title>
  <link href="css/home.css" rel="stylesheet" />

</head>
<body>
<table>
   	<td>
 	<h1 style="font-size:7vw">
       	      Welcome to <br />
                     Our Health Care  Center
 </h1>		
	<a href="loginpage.php" class=" custom_orange-btn mr-3">
            Login 
        </a>
        <a href="registerpage.php" class=" custom_dark-btn">
          Register
        </a>   
	 </td>
	<td >
		 <img src="images/slide-img.png">
	</td>
</table>
</body>

</html>