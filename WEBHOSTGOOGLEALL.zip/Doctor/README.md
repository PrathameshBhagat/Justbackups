 # Doctor-Project
Available At https://prathameshbhagat.000webhostapp.com/Doctor
You Can Register as user or admin <br> 
Then log in as user and book doctors Appointment<br>
Or log in as Admin to get all the bookings till now on login as admin<br>

#### Micro-Project/Freelance-Project completed in a day (in one day [8hrs]) .
